function result=lf   %linefeed
if (nargout>0)
    result=sprintf('\n');
else
    disp(sprintf('\n'))
end