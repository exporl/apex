function dir=makedirend(dir,create)
% ensure dir ends in delim
% if create==1 the dir wil be created if it doesn't exist yet

if (nargin<2)
    create=0;
end

% if (isunix)
    delim='/';
% else
%     delim='\';
% end

if (length(dir)==0)
    dir='';
    return;
end
   

if (dir(end)~=delim)
        dir=[dir delim];
end

dir=removedoubledelim(dir);

if (create)
    if (~exist(dir))
        disp(['Creating ' dir]);
%         mkdir(dir, '.');
        mkdir(dir);
    end
end


    return; 
   
    
    function r=removedoubledelim(r)
       for i=1:length(r)-1
          if (r(i)==delim && r(i+1)==delim)
              r=removedoubledelim( r([1:i i+2:end]));
              break;
          end
       end
    end
    
end