function result=tb   %linefeed
if (nargout>0)
    result=sprintf('\t');
else
    disp(sprintf('\t'))
end