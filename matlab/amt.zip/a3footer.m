function result=a3footer

result=readfile('footer.xml');