function result=bool2xml(param)

if (param)
    result='true';
else
    result='false';
end