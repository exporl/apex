function result=a3noisegen

result=readfile('a3templates/noisegen.xml');