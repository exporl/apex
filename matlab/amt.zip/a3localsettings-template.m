function r=a3localsettings
% return apex 3 toolbox settings

% path to xalan
r.xalancmd='/usr/bin/xalan';
r.apex_path='/home/tom/data/apex/';
r.apex_schema=[r.apex_path 'schemas/apex-schema.xsd'];
r.apex_xslt_scripts=[r.apex_path 'data/xslt/'];
r.xml_check_tool='/usr/bin/xmllint';
