this_dir = fileparts(which(mfilename));
addpath(this_dir);
addpath([this_dir filesep 'a3templates']);
addpath([this_dir filesep 'tools']);
savepath
