function s=a3easstimulus(id, acdb, eldb)
% a3easstimulus(id, acdb, eldb)

 s=['<stimulus id="' id '" >'];
    s=[s lf '<datablocks>'];
    s=[s lf '<simultaneous>'];
    s=[s lf '<sequential>'];
    s=[s lf '<datablock id="waitforl34"/>'];
    s=[s lf '<datablock id="' acdb  '" />'];
    s=[s lf '</sequential>'];
    s=[s lf '<datablock id="' eldb '" />'];
    s=[s lf '</simultaneous>'];
    s=[s lf '</datablocks>'];
    s=[s lf '</stimulus>'];