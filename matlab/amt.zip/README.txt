This archive contains the Apex Matlab Toolbox
To install:
    - copy it to a directory
    - start Matlab
    - point matlab to the directory
    - run install_amt
    - type help Contents for more information
    
tom.francart@med.kuleuven.be
